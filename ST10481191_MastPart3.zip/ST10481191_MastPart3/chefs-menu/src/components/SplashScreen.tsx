import React, { useEffect, useState } from "react";

interface SplashProps {
  onFinish: () => void;
}

const SplashScreen: React.FC<SplashProps> = ({ onFinish }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const progressInterval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          return 100;
        }
        return prev + 4;
      });
    }, 40);

    const timer = setTimeout(onFinish, 10000);

    return () => {
      clearInterval(progressInterval);
      clearTimeout(timer);
    };
  }, [onFinish]);

  return (
    <div style={styles.container}>
      <div style={styles.content}>
        {/* Clean Logo */}
        <div style={styles.logo}>
          <div style={styles.logoIcon}>👨‍🍳</div>
          <h1 style={styles.title}>Chef's Menu</h1>
        </div>

        {/* Simple Progress Bar */}
        <div style={styles.progressContainer}>
          <div style={styles.progressBar}>
            <div 
              style={{
                ...styles.progressFill,
                width: `${progress}%`
              }}
            ></div>
          </div>
          <p style={styles.loadingText}>
            Loading kitchen management system...
          </p>
        </div>

        {/* Minimal Footer */}
        <div style={styles.footer}>
          <p style={styles.footerText}>Professional Kitchen Management</p>
        </div>
      </div>
    </div>
  );
};

const styles: Record<string, React.CSSProperties> = {
  container: {
    height: "100vh",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#1a1a1a",
    color: "white",
    fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif"
  },
  content: {
    textAlign: "center",
    maxWidth: "400px",
    padding: "0 20px"
  },
  logo: {
    marginBottom: "50px"
  },
  logoIcon: {
    fontSize: "4rem",
    marginBottom: "1rem",
    opacity: 0.9
  },
  title: {
    fontSize: "2.5rem",
    fontWeight: "700",
    margin: "0",
    color: "#ffffff",
    letterSpacing: "-0.5px"
  },
  progressContainer: {
    marginBottom: "50px"
  },
  progressBar: {
    width: "300px",
    height: "3px",
    backgroundColor: "rgba(255, 255, 255, 0.2)",
    borderRadius: "2px",
    overflow: "hidden",
    margin: "0 auto 15px auto"
  },
  progressFill: {
    height: "100%",
    backgroundColor: "#ffffff",
    borderRadius: "2px",
    transition: "width 0.3s ease"
  },
  loadingText: {
    fontSize: "0.9rem",
    color: "rgba(255, 255, 255, 0.7)",
    margin: "0",
    fontWeight: "400"
  },
  footer: {
    marginTop: "30px"
  },
  footerText: {
    fontSize: "0.8rem",
    color: "rgba(255, 255, 255, 0.5)",
    margin: "0",
    fontWeight: "300"
  }
};

export default SplashScreen;