import React, { useState } from "react";

interface MainMenuProps {
  onSelectCategory: (category: string) => void;
}

interface MenuItem {
  name: string;
  price: number;
  description: string;
  category: string;
}

const MainMenu: React.FC<MainMenuProps> = ({ onSelectCategory }) => {
  const [hoveredCategory, setHoveredCategory] = useState<string | null>(null);
  const [showMenuList, setShowMenuList] = useState(false);
  
  const categories = [
    { 
      name: "Starters", 
      description: "Appetizers & Small Plates",
      image: "https://images.unsplash.com/photo-1563379926898-05f4575a45d8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8c3RhcnRlciUyMGRpc2h8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=800&q=60",
      items: "4 dishes"
    },
    { 
      name: "Mains", 
      description: "Main Courses & Entrees",
      image: "https://images.unsplash.com/photo-1572802419224-296b0aeee0d9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fG1haW4lMjBjb3Vyc2V8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=800&q=60",
      items: "5 dishes"
    },
    { 
      name: "Desserts", 
      description: "Sweet Endings & Treats",
      image: "https://images.unsplash.com/photo-1551024506-0bccd828d307?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8ZGVzc2VydHxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=800&q=60",
      items: "3 dishes"
    }
  ];

  const menuItems: MenuItem[] = [
    // Starters
    { name: "Truffle Arancini", price: 145, description: "Crispy risotto balls with black truffle", category: "Starters" },
    { name: "Seared Scallops", price: 185, description: "With cauliflower purée and caviar", category: "Starters" },
    { name: "Burrata Salad", price: 125, description: "Fresh burrata with heirloom tomatoes", category: "Starters" },
    { name: "Beef Tartare", price: 165, description: "Hand-cut beef with capers and quail egg", category: "Starters" },
    
    // Mains
    { name: "Wagyu Beef Fillet", price: 495, description: "Premium beef with truffle mash", category: "Mains" },
    { name: "Wild Mushroom Risotto", price: 165, description: "Creamy arborio rice with wild mushrooms", category: "Mains" },
    { name: "Herb-Crusted Salmon", price: 195, description: "Atlantic salmon with lemon butter sauce", category: "Mains" },
    { name: "Duck Confit", price: 225, description: "Slow-cooked duck with potato gratin", category: "Mains" },
    { name: "Vegetable Wellington", price: 175, description: "Seasonal vegetables in puff pastry", category: "Mains" },
    
    // Desserts
    { name: "Chocolate Soufflé", price: 95, description: "Warm chocolate soufflé with ice cream", category: "Desserts" },
    { name: "Berry Pavlova", price: 85, description: "Crisp meringue with fresh berries", category: "Desserts" },
    { name: "Tiramisu", price: 75, description: "Classic Italian coffee dessert", category: "Desserts" }
  ];

  const getItemsByCategory = (category: string) => {
    return menuItems.filter(item => item.category === category);
  };

  const getTotalValue = () => {
    return menuItems.reduce((sum, item) => sum + item.price, 0);
  };

  return (
    <div style={styles.container}>
      {/* Header Section */}
      <div style={styles.header}>
        <div style={styles.logo}>
          <span style={styles.logoIcon}>👨‍🍳</span>
          <div style={styles.logoText}>
            <h1 style={styles.title}>Chef's Menu</h1>
            <p style={styles.subtitle}>Professional Kitchen Management</p>
          </div>
        </div>
        <button 
          onClick={() => setShowMenuList(!showMenuList)}
          style={styles.viewMenuBtn}
        >
          {showMenuList ? "Hide Menu" : "View Full Menu"}
        </button>
      </div>

      {/* Hero Section */}
      <div style={styles.hero}>
        <h2 style={styles.heroTitle}>Menu Categories</h2>
        <p style={styles.heroSubtitle}>
          {showMenuList ? "Complete menu overview" : "Select a category to manage your dishes"}
        </p>
      </div>

      {showMenuList ? (
        /* Full Menu List */
        <div style={styles.menuListContainer}>
          <div style={styles.menuList}>
            {categories.map((category) => (
              <div key={category.name} style={styles.menuCategory}>
                <div style={styles.categoryHeader}>
                  <h3 style={styles.categoryTitle}>{category.name}</h3>
                  <span style={styles.itemCount}>{getItemsByCategory(category.name).length} items</span>
                </div>
                <div style={styles.menuItems}>
                  {getItemsByCategory(category.name).map((item, index) => (
                    <div key={index} style={styles.menuItem}>
                      <div style={styles.itemInfo}>
                        <h4 style={styles.itemName}>{item.name}</h4>
                        <p style={styles.itemDescription}>{item.description}</p>
                      </div>
                      <span style={styles.itemPrice}>R{item.price}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
          
          {/* Menu Summary */}
          <div style={styles.menuSummary}>
            <h3 style={styles.summaryTitle}>Menu Summary</h3>
            <div style={styles.summaryStats}>
              <div style={styles.summaryStat}>
                <span style={styles.summaryNumber}>{menuItems.length}</span>
                <span style={styles.summaryLabel}>Total Dishes</span>
              </div>
              <div style={styles.summaryStat}>
                <span style={styles.summaryNumber}>R{getTotalValue()}</span>
                <span style={styles.summaryLabel}>Total Value</span>
              </div>
              <div style={styles.summaryStat}>
                <span style={styles.summaryNumber}>
                  R{(getTotalValue() / menuItems.length).toFixed(0)}
                </span>
                <span style={styles.summaryLabel}>Average Price</span>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Categories Grid */
        <>
          <div style={styles.categoriesGrid}>
            {categories.map((category) => (
              <div
                key={category.name}
                style={{
                  ...styles.categoryCard,
                  transform: hoveredCategory === category.name ? 'translateY(-4px)' : 'translateY(0)',
                  boxShadow: hoveredCategory === category.name 
                    ? '0 8px 30px rgba(0, 0, 0, 0.12)' 
                    : '0 4px 20px rgba(0, 0, 0, 0.08)'
                }}
                onMouseEnter={() => setHoveredCategory(category.name)}
                onMouseLeave={() => setHoveredCategory(null)}
                onClick={() => onSelectCategory(category.name)}
              >
                {/* Category Image */}
                <div style={styles.imageContainer}>
                  <img 
                    src={category.image} 
                    alt={category.name}
                    style={{
                      ...styles.categoryImage,
                      transform: hoveredCategory === category.name ? 'scale(1.05)' : 'scale(1)'
                    }}
                  />
                  <div style={styles.imageOverlay}></div>
                </div>
                
                {/* Category Content */}
                <div style={styles.categoryContent}>
                  <h3 style={styles.categoryName}>{category.name}</h3>
                  <p style={styles.categoryDescription}>{category.description}</p>
                  <div style={styles.categoryMeta}>
                    <span style={styles.itemCount}>{category.items}</span>
                  </div>
                  <div style={{
                    ...styles.ctaButton,
                    backgroundColor: hoveredCategory === category.name ? '#000' : '#1a1a1a'
                  }}>
                    <span style={styles.ctaText}>Manage Dishes</span>
                    <span style={{
                      ...styles.arrow,
                      transform: hoveredCategory === category.name ? 'translateX(4px)' : 'translateX(0)'
                    }}>→</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Stats Section */}
          <div style={styles.stats}>
            <div style={styles.statItem}>
              <span style={styles.statNumber}>{menuItems.length}</span>
              <span style={styles.statLabel}>Total Dishes</span>
            </div>
            <div style={styles.statItem}>
              <span style={styles.statNumber}>{categories.length}</span>
              <span style={styles.statLabel}>Categories</span>
            </div>
            <div style={styles.statItem}>
              <span style={styles.statNumber}>R {getTotalValue()}</span>
              <span style={styles.statLabel}>Menu Value</span>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

const styles: Record<string, React.CSSProperties> = {
  container: {
    minHeight: "100vh",
    backgroundColor: "#f8f9fa",
    padding: "40px 24px",
    fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif"
  },
  header: {
    maxWidth: "1200px",
    margin: "0 auto 48px auto",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center"
  },
  logo: {
    display: "flex",
    alignItems: "center",
    gap: "16px"
  },
  logoIcon: {
    fontSize: "48px",
    background: "linear-gradient(45deg, #FF6B6B, #FFA726)",
    borderRadius: "12px",
    padding: "12px",
    boxShadow: "0 4px 12px rgba(255, 107, 107, 0.3)"
  },
  logoText: {
    display: "flex",
    flexDirection: "column"
  },
  title: {
    fontSize: "32px",
    fontWeight: "700",
    color: "#1a1a1a",
    margin: "0 0 4px 0",
    letterSpacing: "-0.5px"
  },
  subtitle: {
    fontSize: "14px",
    color: "#666",
    fontWeight: "400",
    margin: 0
  },
  viewMenuBtn: {
    padding: "12px 24px",
    backgroundColor: "#1a1a1a",
    color: "white",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
    fontSize: "14px",
    fontWeight: "500",
    transition: "all 0.2s ease"
  },
  hero: {
    textAlign: "center",
    maxWidth: "600px",
    margin: "0 auto 48px auto"
  },
  heroTitle: {
    fontSize: "36px",
    fontWeight: "600",
    color: "#1a1a1a",
    margin: "0 0 12px 0",
    letterSpacing: "-0.5px"
  },
  heroSubtitle: {
    fontSize: "16px",
    color: "#666",
    lineHeight: "1.5",
    margin: 0
  },
  categoriesGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(340px, 1fr))",
    gap: "32px",
    maxWidth: "1200px",
    margin: "0 auto 48px auto"
  },
  categoryCard: {
    backgroundColor: "white",
    borderRadius: "16px",
    overflow: "hidden",
    cursor: "pointer",
    transition: "all 0.3s ease",
    border: "1px solid rgba(0, 0, 0, 0.05)"
  },
  imageContainer: {
    position: "relative",
    height: "200px",
    overflow: "hidden"
  },
  categoryImage: {
    width: "100%",
    height: "100%",
    objectFit: "cover",
    transition: "transform 0.3s ease"
  },
  imageOverlay: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    background: "linear-gradient(to bottom, transparent 0%, rgba(0,0,0,0.1) 100%)"
  },
  categoryContent: {
    padding: "24px"
  },
  categoryName: {
    fontSize: "24px",
    fontWeight: "600",
    color: "#1a1a1a",
    margin: "0 0 8px 0"
  },
  categoryDescription: {
    fontSize: "14px",
    color: "#666",
    lineHeight: "1.5",
    margin: "0 0 16px 0"
  },
  categoryMeta: {
    display: "flex",
    alignItems: "center",
    marginBottom: "20px"
  },
  itemCount: {
    fontSize: "13px",
    color: "#888",
    fontWeight: "500"
  },
  ctaButton: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "12px 16px",
    color: "white",
    borderRadius: "8px",
    transition: "all 0.2s ease"
  },
  ctaText: {
    fontSize: "14px",
    fontWeight: "500"
  },
  arrow: {
    fontSize: "16px",
    transition: "transform 0.2s ease"
  },
  stats: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
    gap: "24px",
    maxWidth: "800px",
    margin: "0 auto",
    padding: "32px",
    backgroundColor: "white",
    borderRadius: "16px",
    boxShadow: "0 4px 20px rgba(0, 0, 0, 0.08)"
  },
  statItem: {
    textAlign: "center",
    padding: "20px"
  },
  statNumber: {
    display: "block",
    fontSize: "32px",
    fontWeight: "700",
    color: "#1a1a1a",
    marginBottom: "8px"
  },
  statLabel: {
    fontSize: "14px",
    color: "#666",
    fontWeight: "500"
  },
  // Menu List Styles
  menuListContainer: {
    maxWidth: "1000px",
    margin: "0 auto"
  },
  menuList: {
    display: "flex",
    flexDirection: "column",
    gap: "32px",
    marginBottom: "32px"
  },
  menuCategory: {
    backgroundColor: "white",
    borderRadius: "16px",
    padding: "32px",
    boxShadow: "0 4px 20px rgba(0, 0, 0, 0.08)"
  },
  categoryHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: "24px",
    paddingBottom: "16px",
    borderBottom: "2px solid #f0f0f0"
  },
  categoryTitle: {
    fontSize: "24px",
    fontWeight: "600",
    color: "#1a1a1a",
    margin: 0
  },
  menuItems: {
    display: "flex",
    flexDirection: "column",
    gap: "16px"
  },
  menuItem: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-start",
    padding: "16px",
    backgroundColor: "#fafafa",
    borderRadius: "8px",
    transition: "background-color 0.2s ease"
  },
  itemInfo: {
    flex: 1
  },
  itemName: {
    fontSize: "16px",
    fontWeight: "600",
    color: "#1a1a1a",
    margin: "0 0 4px 0"
  },
  itemDescription: {
    fontSize: "14px",
    color: "#666",
    lineHeight: "1.4",
    margin: 0
  },
  itemPrice: {
    fontSize: "16px",
    fontWeight: "600",
    color: "#28a745",
    marginLeft: "16px"
  },
  menuSummary: {
    backgroundColor: "white",
    borderRadius: "16px",
    padding: "32px",
    boxShadow: "0 4px 20px rgba(0, 0, 0, 0.08)"
  },
  summaryTitle: {
    fontSize: "20px",
    fontWeight: "600",
    color: "#1a1a1a",
    margin: "0 0 24px 0",
    textAlign: "center"
  },
  summaryStats: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))",
    gap: "24px"
  },
  summaryStat: {
    textAlign: "center",
    padding: "20px"
  },
  summaryNumber: {
    display: "block",
    fontSize: "28px",
    fontWeight: "700",
    color: "#1a1a1a",
    marginBottom: "8px"
  },
  summaryLabel: {
    fontSize: "14px",
    color: "#666",
    fontWeight: "500"
  }
};

export default MainMenu;