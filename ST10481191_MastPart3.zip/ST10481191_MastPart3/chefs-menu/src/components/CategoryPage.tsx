import React, { useState, useEffect } from "react";

interface MenuItem {
  name: string;
  price: number;
  description: string;
  category: string;
  ingredients?: string[];
  spiceLevel?: number;
  preparationTime?: number;
  isVegetarian?: boolean;
  isVegan?: boolean;
  isGlutenFree?: boolean;
}

interface CategoryPageProps {
  category: string;
  onBack: () => void;
}

const CategoryPage: React.FC<CategoryPageProps> = ({ category, onBack }) => {
  const [items, setItems] = useState<MenuItem[]>([]);
  const [form, setForm] = useState<MenuItem>({
    name: "",
    price: 0,
    description: "",
    category: category,
    ingredients: [],
    spiceLevel: 0,
    preparationTime: 0,
    isVegetarian: false,
    isVegan: false,
    isGlutenFree: false
  });
  
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState<"name" | "price" | "preparationTime">("name");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc");
  const [filters, setFilters] = useState({
    vegetarian: false,
    vegan: false,
    glutenFree: false,
    spiceLevel: 0,
    maxPrice: 1000
  });
  const [ingredientInput, setIngredientInput] = useState("");

  // Sample initial menu items based on category
  useEffect(() => {
    const sampleItems: { [key: string]: MenuItem[] } = {
      Starters: [
        {
          name: "Truffle Arancini",
          price: 145,
          description: "Crispy risotto balls with black truffle and mozzarella",
          category: "Starters",
          ingredients: ["Arborio rice", "Black truffle", "Mozzarella", "Panko breadcrumbs"],
          spiceLevel: 0,
          preparationTime: 25,
          isVegetarian: true,
          isGlutenFree: false
        },
        {
          name: "Seared Scallops",
          price: 185,
          description: "Perfectly seared scallops with cauliflower purée and caviar",
          category: "Starters",
          ingredients: ["Scallops", "Cauliflower", "Caviar", "Micro herbs"],
          spiceLevel: 1,
          preparationTime: 20,
          isVegetarian: false,
          isGlutenFree: true
        }
      ],
      Mains: [
        {
          name: "Wagyu Beef Fillet",
          price: 495,
          description: "Premium wagyu beef with truffle mash and red wine jus",
          category: "Mains",
          ingredients: ["Wagyu beef", "Potatoes", "Truffle", "Red wine", "Seasonal vegetables"],
          spiceLevel: 0,
          preparationTime: 35,
          isVegetarian: false,
          isGlutenFree: true
        },
        {
          name: "Wild Mushroom Risotto",
          price: 165,
          description: "Creamy arborio rice with seasonal wild mushrooms and parmesan",
          category: "Mains",
          ingredients: ["Arborio rice", "Wild mushrooms", "Parmesan", "White wine", "Truffle oil"],
          spiceLevel: 0,
          preparationTime: 30,
          isVegetarian: true,
          isVegan: false,
          isGlutenFree: true
        }
      ],
      Desserts: [
        {
          name: "Chocolate Soufflé",
          price: 95,
          description: "Warm chocolate soufflé with vanilla bean ice cream",
          category: "Desserts",
          ingredients: ["Dark chocolate", "Eggs", "Sugar", "Vanilla ice cream"],
          spiceLevel: 0,
          preparationTime: 25,
          isVegetarian: true,
          isGlutenFree: false
        },
        {
          name: "Berry Pavlova",
          price: 85,
          description: "Crisp meringue with fresh berries and chantilly cream",
          category: "Desserts",
          ingredients: ["Egg whites", "Sugar", "Mixed berries", "Whipped cream", "Mint"],
          spiceLevel: 0,
          preparationTime: 20,
          isVegetarian: true,
          isGlutenFree: true
        }
      ]
    };
    
    setItems(sampleItems[category] || []);
  }, [category]);

  const addItem = () => {
    if (!form.name.trim()) {
      alert("Please enter an item name");
      return;
    }
    const newItem: MenuItem = {
      ...form,
      category: category,
      // Ensure all optional fields have default values
      ingredients: form.ingredients || [],
      spiceLevel: form.spiceLevel || 0,
      preparationTime: form.preparationTime || 0,
      isVegetarian: form.isVegetarian || false,
      isVegan: form.isVegan || false,
      isGlutenFree: form.isGlutenFree || false
    };
    setItems([...items, newItem]);
    setForm({
      name: "",
      price: 0,
      description: "",
      category: category,
      ingredients: [],
      spiceLevel: 0,
      preparationTime: 0,
      isVegetarian: false,
      isVegan: false,
      isGlutenFree: false
    });
  };

  const addIngredient = () => {
    if (ingredientInput.trim()) {
      setForm({
        ...form,
        ingredients: [...(form.ingredients || []), ingredientInput.trim()]
      });
      setIngredientInput("");
    }
  };

  const removeIngredient = (index: number) => {
    setForm({
      ...form,
      ingredients: (form.ingredients || []).filter((_, i) => i !== index)
    });
  };

  // Safe getter functions with defaults
  const getSpiceLevel = (item: MenuItem): number => item.spiceLevel || 0;
  const getPreparationTime = (item: MenuItem): number => item.preparationTime || 0;
  const getIngredients = (item: MenuItem): string[] => item.ingredients || [];
  const isVegetarian = (item: MenuItem): boolean => item.isVegetarian || false;
  const isVegan = (item: MenuItem): boolean => item.isVegan || false;
  const isGlutenFree = (item: MenuItem): boolean => item.isGlutenFree || false;

  // Filter and sort items
  const filteredAndSortedItems = items
    .filter(item => {
      const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           item.description.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesVegetarian = !filters.vegetarian || isVegetarian(item);
      const matchesVegan = !filters.vegan || isVegan(item);
      const matchesGlutenFree = !filters.glutenFree || isGlutenFree(item);
      const matchesSpiceLevel = getSpiceLevel(item) <= filters.spiceLevel;
      const matchesPrice = item.price <= filters.maxPrice;
      
      return matchesSearch && matchesVegetarian && matchesVegan && matchesGlutenFree && 
             matchesSpiceLevel && matchesPrice;
    })
    .sort((a, b) => {
      if (sortBy === "name") {
        return sortOrder === "asc" 
          ? a.name.localeCompare(b.name)
          : b.name.localeCompare(a.name);
      } else if (sortBy === "price") {
        return sortOrder === "asc" ? a.price - b.price : b.price - a.price;
      } else {
        const timeA = getPreparationTime(a);
        const timeB = getPreparationTime(b);
        return sortOrder === "asc" ? timeA - timeB : timeB - timeA;
      }
    });

  const clearFilters = () => {
    setFilters({
      vegetarian: false,
      vegan: false,
      glutenFree: false,
      spiceLevel: 0,
      maxPrice: 1000
    });
    setSearchTerm("");
  };

  // Render spice level with emojis
  const renderSpiceLevel = (level: number) => {
    if (level === 0) return "Mild";
    if (level === 1) return "🌶️ Mild";
    if (level === 2) return "🌶️🌶️ Medium";
    return "🌶️🌶️🌶️ Spicy";
  };

  return (
    <div style={styles.container}>
      {/* Header */}
      <div style={styles.header}>
        <button onClick={onBack} style={styles.backBtn}>
          ← Back to Menu
        </button>
        <h1 style={styles.categoryTitle}>{category}</h1>
        <p style={styles.itemCount}>{filteredAndSortedItems.length} items</p>
      </div>

      <div style={styles.content}>
        {/* Filters Sidebar */}
        <div style={styles.sidebar}>
          <div style={styles.filterSection}>
            <h3 style={styles.filterTitle}>Search & Filter</h3>
            
            {/* Search */}
            <div style={styles.filterGroup}>
              <input
                type="text"
                placeholder="Search menu items..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                style={styles.searchInput}
              />
            </div>

            {/* Dietary Filters */}
            <div style={styles.filterGroup}>
              <label style={styles.filterLabel}>Dietary Preferences</label>
              <div style={styles.checkboxGroup}>
                <label style={styles.checkboxLabel}>
                  <input
                    type="checkbox"
                    checked={filters.vegetarian}
                    onChange={(e) => setFilters({...filters, vegetarian: e.target.checked})}
                  />
                  🌱 Vegetarian
                </label>
                <label style={styles.checkboxLabel}>
                  <input
                    type="checkbox"
                    checked={filters.vegan}
                    onChange={(e) => setFilters({...filters, vegan: e.target.checked})}
                  />
                  💚 Vegan
                </label>
                <label style={styles.checkboxLabel}>
                  <input
                    type="checkbox"
                    checked={filters.glutenFree}
                    onChange={(e) => setFilters({...filters, glutenFree: e.target.checked})}
                  />
                  🌾 Gluten Free
                </label>
              </div>
            </div>

            {/* Spice Level */}
            <div style={styles.filterGroup}>
              <label style={styles.filterLabel}>
                Max Spice Level: {filters.spiceLevel === 0 ? "Mild" : 
                                filters.spiceLevel === 1 ? "Medium" : 
                                filters.spiceLevel === 2 ? "Spicy" : "Very Spicy"}
              </label>
              <input
                type="range"
                min="0"
                max="3"
                value={filters.spiceLevel}
                onChange={(e) => setFilters({...filters, spiceLevel: parseInt(e.target.value)})}
                style={styles.rangeInput}
              />
              <div style={styles.spiceLevelLabels}>
                <span>Mild</span>
                <span>Medium</span>
                <span>Spicy</span>
                <span>Very Spicy</span>
              </div>
            </div>

            {/* Price Range */}
            <div style={styles.filterGroup}>
              <label style={styles.filterLabel}>
                Max Price: R{filters.maxPrice}
              </label>
              <input
                type="range"
                min="0"
                max="1000"
                step="50"
                value={filters.maxPrice}
                onChange={(e) => setFilters({...filters, maxPrice: parseInt(e.target.value)})}
                style={styles.rangeInput}
              />
              <div style={styles.priceLabels}>
                <span>R0</span>
                <span>R500</span>
                <span>R1000</span>
              </div>
            </div>

            {/* Clear Filters */}
            <button onClick={clearFilters} style={styles.clearFiltersBtn}>
              Clear All Filters
            </button>
          </div>
        </div>

        {/* Main Content */}
        <div style={styles.mainContent}>
          {/* Sort Controls */}
          <div style={styles.sortControls}>
            <select 
              value={sortBy} 
              onChange={(e) => setSortBy(e.target.value as any)}
              style={styles.sortSelect}
            >
              <option value="name">Sort by Name</option>
              <option value="price">Sort by Price</option>
              <option value="preparationTime">Sort by Prep Time</option>
            </select>
            <button 
              onClick={() => setSortOrder(sortOrder === "asc" ? "desc" : "asc")}
              style={styles.sortOrderBtn}
            >
              {sortOrder === "asc" ? "↑ Asc" : "↓ Desc"}
            </button>
          </div>

          {/* Add Item Form */}
          <div style={styles.formSection}>
            <h3 style={styles.formTitle}>Add New Menu Item</h3>
            <div style={styles.formGrid}>
              <input
                type="text"
                placeholder="Item name"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                style={styles.input}
              />
              <input
                type="number"
                placeholder="Price"
                value={form.price || ""}
                onChange={(e) => setForm({ ...form, price: parseFloat(e.target.value) || 0 })}
                style={styles.input}
              />
              <input
                type="text"
                placeholder="Description"
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                style={styles.input}
              />
              <input
                type="number"
                placeholder="Preparation time (minutes)"
                value={form.preparationTime || ""}
                onChange={(e) => setForm({ ...form, preparationTime: parseInt(e.target.value) || 0 })}
                style={styles.input}
              />
              
              {/* Spice Level */}
              <div style={styles.formGroup}>
                <label style={styles.formLabel}>Spice Level</label>
                <select
                  value={form.spiceLevel || 0}
                  onChange={(e) => setForm({ ...form, spiceLevel: parseInt(e.target.value) })}
                  style={styles.input}
                >
                  <option value={0}>Mild</option>
                  <option value={1}>Medium</option>
                  <option value={2}>Spicy</option>
                  <option value={3}>Very Spicy</option>
                </select>
              </div>

              {/* Ingredients */}
              <div style={styles.ingredientsSection}>
                <label style={styles.formLabel}>Ingredients</label>
                <div style={styles.ingredientInput}>
                  <input
                    type="text"
                    placeholder="Add ingredient"
                    value={ingredientInput}
                    onChange={(e) => setIngredientInput(e.target.value)}
                    style={styles.input}
                    onKeyPress={(e) => e.key === 'Enter' && addIngredient()}
                  />
                  <button onClick={addIngredient} style={styles.addIngredientBtn}>
                    Add
                  </button>
                </div>
                <div style={styles.ingredientsList}>
                  {(form.ingredients || []).map((ingredient, index) => (
                    <span key={index} style={styles.ingredientTag}>
                      {ingredient}
                      <button 
                        onClick={() => removeIngredient(index)}
                        style={styles.removeIngredientBtn}
                      >
                        ×
                      </button>
                    </span>
                  ))}
                </div>
              </div>

              {/* Dietary Options */}
              <div style={styles.dietaryOptions}>
                <label style={styles.checkboxLabel}>
                  <input
                    type="checkbox"
                    checked={form.isVegetarian || false}
                    onChange={(e) => setForm({ ...form, isVegetarian: e.target.checked })}
                  />
                  Vegetarian
                </label>
                <label style={styles.checkboxLabel}>
                  <input
                    type="checkbox"
                    checked={form.isVegan || false}
                    onChange={(e) => setForm({ ...form, isVegan: e.target.checked })}
                  />
                  Vegan
                </label>
                <label style={styles.checkboxLabel}>
                  <input
                    type="checkbox"
                    checked={form.isGlutenFree || false}
                    onChange={(e) => setForm({ ...form, isGlutenFree: e.target.checked })}
                  />
                  Gluten Free
                </label>
              </div>

              <button onClick={addItem} style={styles.addButton}>
                Add Menu Item
              </button>
            </div>
          </div>

          {/* Menu Items Grid */}
          <div style={styles.menuGrid}>
            {filteredAndSortedItems.length === 0 ? (
              <div style={styles.noItems}>
                <h3>No menu items found</h3>
                <p>Try adjusting your filters or add a new item</p>
              </div>
            ) : (
              filteredAndSortedItems.map((item, i) => (
                <div key={i} style={styles.menuCard}>
                  <div style={styles.cardHeader}>
                    <h3 style={styles.itemName}>{item.name}</h3>
                    <span style={styles.price}>R{item.price.toFixed(2)}</span>
                  </div>
                  
                  <p style={styles.description}>{item.description}</p>
                  
                  <div style={styles.itemDetails}>
                    <div style={styles.detailItem}>
                      <span style={styles.detailLabel}>Prep Time:</span>
                      <span>{getPreparationTime(item)} min</span>
                    </div>
                    <div style={styles.detailItem}>
                      <span style={styles.detailLabel}>Spice Level:</span>
                      <span style={styles.spiceLevel}>
                        {renderSpiceLevel(getSpiceLevel(item))}
                      </span>
                    </div>
                  </div>

                  {getIngredients(item).length > 0 && (
                    <div style={styles.ingredients}>
                      <strong>Ingredients:</strong>
                      <div style={styles.ingredientTags}>
                        {getIngredients(item).map((ingredient, idx) => (
                          <span key={idx} style={styles.ingredientTag}>
                            {ingredient}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  <div style={styles.dietaryTags}>
                    {isVegetarian(item) && <span style={styles.vegetarianTag}>🌱 Vegetarian</span>}
                    {isVegan(item) && <span style={styles.veganTag}>💚 Vegan</span>}
                    {isGlutenFree(item) && <span style={styles.glutenFreeTag}>🌾 Gluten Free</span>}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const styles: Record<string, React.CSSProperties> = {
  container: {
    minHeight: "100vh",
    background: "linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)",
    padding: "20px"
  },
  header: {
    textAlign: "center",
    marginBottom: "30px",
    position: "relative"
  },
  backBtn: {
    position: "absolute",
    left: "0",
    top: "0",
    padding: "10px 20px",
    backgroundColor: "#4CAF50",
    color: "white",
    border: "none",
    borderRadius: "25px",
    cursor: "pointer",
    fontSize: "14px",
    boxShadow: "0 4px 15px rgba(76, 175, 80, 0.3)",
    transition: "all 0.3s ease"
  },
  categoryTitle: {
    fontSize: "3rem",
    fontWeight: "700",
    background: "linear-gradient(45deg, #2C3E50, #4CA1AF)",
    WebkitBackgroundClip: "text",
    WebkitTextFillColor: "transparent",
    backgroundClip: "text",
    margin: "0 0 10px 0"
  },
  itemCount: {
    color: "#666",
    fontSize: "1.1rem",
    margin: 0
  },
  content: {
    display: "grid",
    gridTemplateColumns: "300px 1fr",
    gap: "30px",
    maxWidth: "1400px",
    margin: "0 auto"
  },
  sidebar: {
    backgroundColor: "white",
    borderRadius: "15px",
    padding: "25px",
    boxShadow: "0 10px 40px rgba(0, 0, 0, 0.1)",
    height: "fit-content",
    position: "sticky",
    top: "20px"
  },
  filterSection: {
    marginBottom: "20px"
  },
  filterTitle: {
    fontSize: "1.5rem",
    fontWeight: "600",
    marginBottom: "20px",
    color: "#2C3E50",
    borderBottom: "2px solid #f0f0f0",
    paddingBottom: "10px"
  },
  filterGroup: {
    marginBottom: "25px"
  },
  filterLabel: {
    display: "block",
    fontWeight: "600",
    marginBottom: "10px",
    color: "#34495E",
    fontSize: "14px"
  },
  searchInput: {
    width: "100%",
    padding: "12px 15px",
    border: "2px solid #e0e0e0",
    borderRadius: "10px",
    fontSize: "14px",
    transition: "all 0.3s ease"
  },
  checkboxGroup: {
    display: "flex",
    flexDirection: "column",
    gap: "12px"
  },
  checkboxLabel: {
    display: "flex",
    alignItems: "center",
    gap: "8px",
    fontSize: "14px",
    cursor: "pointer",
    color: "#555"
  },
  rangeInput: {
    width: "100%",
    marginTop: "5px"
  },
  spiceLevelLabels: {
    display: "flex",
    justifyContent: "space-between",
    fontSize: "12px",
    color: "#666",
    marginTop: "5px"
  },
  priceLabels: {
    display: "flex",
    justifyContent: "space-between",
    fontSize: "12px",
    color: "#666",
    marginTop: "5px"
  },
  clearFiltersBtn: {
    width: "100%",
    padding: "12px",
    backgroundColor: "#E74C3C",
    color: "white",
    border: "none",
    borderRadius: "10px",
    cursor: "pointer",
    fontSize: "14px",
    fontWeight: "600",
    transition: "all 0.3s ease"
  },
  mainContent: {
    display: "flex",
    flexDirection: "column",
    gap: "25px"
  },
  sortControls: {
    display: "flex",
    gap: "15px",
    alignItems: "center",
    backgroundColor: "white",
    padding: "20px",
    borderRadius: "15px",
    boxShadow: "0 5px 20px rgba(0, 0, 0, 0.08)"
  },
  sortSelect: {
    padding: "10px 15px",
    border: "2px solid #e0e0e0",
    borderRadius: "8px",
    fontSize: "14px",
    backgroundColor: "white"
  },
  sortOrderBtn: {
    padding: "10px 20px",
    backgroundColor: "#3498DB",
    color: "white",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
    fontSize: "14px",
    fontWeight: "600"
  },
  formSection: {
    backgroundColor: "white",
    borderRadius: "15px",
    padding: "25px",
    boxShadow: "0 10px 40px rgba(0, 0, 0, 0.1)"
  },
  formTitle: {
    fontSize: "1.5rem",
    fontWeight: "600",
    marginBottom: "20px",
    color: "#2C3E50"
  },
  formGrid: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    gap: "15px"
  },
  formGroup: {
    display: "flex",
    flexDirection: "column",
    gap: "5px"
  },
  formLabel: {
    fontWeight: "600",
    color: "#34495E",
    fontSize: "14px",
    marginBottom: "5px"
  },
  input: {
    padding: "12px 15px",
    border: "2px solid #e0e0e0",
    borderRadius: "8px",
    fontSize: "14px",
    transition: "all 0.3s ease"
  },
  ingredientsSection: {
    gridColumn: "1 / -1"
  },
  ingredientInput: {
    display: "flex",
    gap: "10px",
    marginBottom: "10px"
  },
  addIngredientBtn: {
    padding: "12px 20px",
    backgroundColor: "#27AE60",
    color: "white",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
    fontSize: "14px",
    whiteSpace: "nowrap"
  },
  ingredientsList: {
    display: "flex",
    flexWrap: "wrap",
    gap: "8px",
    marginTop: "10px"
  },
  ingredientTag: {
    display: "inline-flex",
    alignItems: "center",
    gap: "5px",
    backgroundColor: "#EBF5FB",
    padding: "5px 12px",
    borderRadius: "20px",
    fontSize: "12px",
    color: "#2874A6"
  },
  removeIngredientBtn: {
    background: "none",
    border: "none",
    color: "#E74C3C",
    cursor: "pointer",
    fontSize: "16px",
    padding: 0,
    width: "16px",
    height: "16px"
  },
  dietaryOptions: {
    gridColumn: "1 / -1",
    display: "flex",
    gap: "20px",
    justifyContent: "center"
  },
  addButton: {
    gridColumn: "1 / -1",
    padding: "15px",
    backgroundColor: "#9B59B6",
    color: "white",
    border: "none",
    borderRadius: "10px",
    cursor: "pointer",
    fontSize: "16px",
    fontWeight: "600",
    transition: "all 0.3s ease"
  },
  menuGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fill, minmax(350px, 1fr))",
    gap: "25px"
  },
  menuCard: {
    backgroundColor: "white",
    borderRadius: "15px",
    padding: "25px",
    boxShadow: "0 10px 40px rgba(0, 0, 0, 0.1)",
    transition: "all 0.3s ease",
    border: "1px solid #f0f0f0"
  },
  cardHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: "15px"
  },
  itemName: {
    fontSize: "1.4rem",
    fontWeight: "600",
    color: "#2C3E50",
    margin: 0,
    flex: 1
  },
  price: {
    fontSize: "1.3rem",
    fontWeight: "700",
    color: "#27AE60",
    marginLeft: "15px"
  },
  description: {
    color: "#666",
    lineHeight: "1.6",
    marginBottom: "15px",
    fontSize: "14px"
  },
  itemDetails: {
    display: "flex",
    gap: "20px",
    marginBottom: "15px",
    fontSize: "13px"
  },
  detailItem: {
    display: "flex",
    flexDirection: "column",
    gap: "5px"
  },
  detailLabel: {
    fontWeight: "600",
    color: "#7F8C8D",
    fontSize: "12px"
  },
  spiceLevel: {
    color: "#E74C3C",
    fontWeight: "600"
  },
  ingredients: {
    marginBottom: "15px"
  },
  ingredientTags: {
    display: "flex",
    flexWrap: "wrap",
    gap: "8px",
    marginTop: "8px"
  },
  dietaryTags: {
    display: "flex",
    flexWrap: "wrap",
    gap: "8px"
  },
  vegetarianTag: {
    backgroundColor: "#D5F5E3",
    color: "#27AE60",
    padding: "4px 10px",
    borderRadius: "12px",
    fontSize: "11px",
    fontWeight: "600"
  },
  veganTag: {
    backgroundColor: "#D1F2EB",
    color: "#1ABC9C",
    padding: "4px 10px",
    borderRadius: "12px",
    fontSize: "11px",
    fontWeight: "600"
  },
  glutenFreeTag: {
    backgroundColor: "#FCF3CF",
    color: "#F39C12",
    padding: "4px 10px",
    borderRadius: "12px",
    fontSize: "11px",
    fontWeight: "600"
  },
  noItems: {
    gridColumn: "1 / -1",
    textAlign: "center",
    padding: "60px 20px",
    color: "#7F8C8D"
  }
};

export default CategoryPage;