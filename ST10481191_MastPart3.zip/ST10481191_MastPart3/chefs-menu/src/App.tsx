import React, { useState, useEffect } from "react";
import SplashScreen from "./components/SplashScreen";
import MainMenu from "./components/MainMenu";
import CategoryPage from "./components/CategoryPage";
import "./App.css";

const App: React.FC = () => {
  const [showSplash, setShowSplash] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [appReady, setAppReady] = useState(false);

  // Preload any necessary resources
  useEffect(() => {
    // Simulate resource loading
    const timer = setTimeout(() => {
      setAppReady(true);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  // Handle smooth transitions between components
  const handleCategorySelect = (category: string) => {
    setSelectedCategory(category);
  };

  const handleBackToMenu = () => {
    setSelectedCategory(null);
  };

  const handleSplashFinish = () => {
    setShowSplash(false);
  };

  // Render loading state if app isn't ready
  if (!appReady && showSplash) {
    return (
      <div style={styles.loadingContainer}>
        <div style={styles.loadingSpinner}>
          <div style={styles.spinnerCircle}></div>
        </div>
        <p style={styles.loadingText}>Initializing Culinary Experience...</p>
      </div>
    );
  }

  return (
    <div style={styles.appContainer}>
      {/* Global Background Effects */}
      <div style={styles.backgroundEffects}>
        <div style={styles.floatingParticle1}></div>
        <div style={styles.floatingParticle2}></div>
        <div style={styles.floatingParticle3}></div>
        <div style={styles.floatingParticle4}></div>
      </div>

      {/* Main App Content with Transition Effects */}
      <div style={styles.contentWrapper}>
        {showSplash ? (
          <div style={styles.componentContainer}>
            <SplashScreen onFinish={handleSplashFinish} />
          </div>
        ) : selectedCategory ? (
          <div 
            style={{
              ...styles.componentContainer,
              ...styles.slideInFromRight
            }}
          >
            <CategoryPage
              category={selectedCategory}
              onBack={handleBackToMenu}
            />
          </div>
        ) : (
          <div 
            style={{
              ...styles.componentContainer,
              ...styles.slideInFromLeft
            }}
          >
            <MainMenu onSelectCategory={handleCategorySelect} />
          </div>
        )}
      </div>

      {/* Global App Footer */}
      {!showSplash && (
        <footer style={styles.globalFooter}>
          <div style={styles.footerContent}>
            <span style={styles.footerText}>🍳 Chef's Menu Pro</span>
            <span style={styles.footerDivider}>•</span>
            <span style={styles.footerText}>Culinary Excellence</span>
            <span style={styles.footerDivider}>•</span>
            <span style={styles.footerText}>Premium Experience</span>
          </div>
        </footer>
      )}

      {/* Audio Context for Future Sound Effects */}
      <audio preload="none" id="transition-sound" src="" />
    </div>
  );
};

const styles: Record<string, React.CSSProperties> = {
  appContainer: {
    position: "relative",
    minHeight: "100vh",
    overflow: "hidden",
    fontFamily: "'Inter', 'Segoe UI', 'Roboto', sans-serif",
    background: "linear-gradient(135deg, #0c2461 0%, #1e3799 50%, #4a69bd 100%)"
  },
  loadingContainer: {
    height: "100vh",
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    background: "linear-gradient(135deg, #0c2461 0%, #1e3799 100%)",
    color: "white"
  },
  loadingSpinner: {
    width: "80px",
    height: "80px",
    position: "relative",
    marginBottom: "20px"
  },
  spinnerCircle: {
    width: "100%",
    height: "100%",
    border: "4px solid rgba(255, 255, 255, 0.3)",
    borderTop: "4px solid #FFD700",
    borderRadius: "50%",
    animation: "spin 1s linear infinite"
  },
  loadingText: {
    fontSize: "1.1rem",
    fontWeight: "300",
    letterSpacing: "1px",
    opacity: "0.8",
    margin: 0
  },
  backgroundEffects: {
    position: "fixed",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    pointerEvents: "none",
    zIndex: 0
  },
  floatingParticle1: {
    position: "absolute",
    top: "20%",
    left: "10%",
    width: "4px",
    height: "4px",
    backgroundColor: "rgba(255, 215, 0, 0.6)",
    borderRadius: "50%",
    animation: "floatParticle 8s ease-in-out infinite",
    boxShadow: "0 0 20px 2px rgba(255, 215, 0, 0.5)"
  },
  floatingParticle2: {
    position: "absolute",
    top: "60%",
    right: "15%",
    width: "3px",
    height: "3px",
    backgroundColor: "rgba(255, 255, 255, 0.4)",
    borderRadius: "50%",
    animation: "floatParticle 12s ease-in-out infinite reverse",
    boxShadow: "0 0 15px 1px rgba(255, 255, 255, 0.3)"
  },
  floatingParticle3: {
    position: "absolute",
    bottom: "30%",
    left: "20%",
    width: "5px",
    height: "5px",
    backgroundColor: "rgba(255, 165, 0, 0.5)",
    borderRadius: "50%",
    animation: "floatParticle 10s ease-in-out infinite 2s",
    boxShadow: "0 0 25px 3px rgba(255, 165, 0, 0.4)"
  },
  floatingParticle4: {
    position: "absolute",
    top: "40%",
    right: "25%",
    width: "2px",
    height: "2px",
    backgroundColor: "rgba(255, 255, 255, 0.3)",
    borderRadius: "50%",
    animation: "floatParticle 15s ease-in-out infinite 1s",
    boxShadow: "0 0 10px 1px rgba(255, 255, 255, 0.2)"
  },
  contentWrapper: {
    position: "relative",
    zIndex: 1,
    minHeight: "100vh"
  },
  componentContainer: {
    width: "100%",
    height: "100%",
    transition: "transform 0.5s ease-in-out, opacity 0.5s ease-in-out"
  },
  slideInFromRight: {
    animation: "slideInFromRight 0.6s ease-out"
  },
  slideInFromLeft: {
    animation: "slideInFromLeft 0.6s ease-out"
  },
  globalFooter: {
    position: "fixed",
    bottom: 0,
    left: 0,
    right: 0,
    background: "linear-gradient(90deg, transparent, rgba(255,255,255,0.1), transparent)",
    backdropFilter: "blur(10px)",
    borderTop: "1px solid rgba(255, 255, 255, 0.1)",
    padding: "15px 20px",
    zIndex: 1000
  },
  footerContent: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    gap: "20px",
    flexWrap: "wrap"
  },
  footerText: {
    color: "rgba(255, 255, 255, 0.7)",
    fontSize: "0.9rem",
    fontWeight: "300",
    letterSpacing: "0.5px"
  },
  footerDivider: {
    color: "rgba(255, 255, 255, 0.4)",
    fontSize: "0.8rem"
  }
};

// Add global CSS animations
const globalStyles = `
@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

@keyframes floatParticle {
  0%, 100% {
    transform: translateY(0px) translateX(0px) scale(1);
    opacity: 0.7;
  }
  25% {
    transform: translateY(-40px) translateX(20px) scale(1.2);
    opacity: 1;
  }
  50% {
    transform: translateY(-20px) translateX(-20px) scale(0.8);
    opacity: 0.5;
  }
  75% {
    transform: translateY(30px) translateX(10px) scale(1.1);
    opacity: 0.9;
  }
}

@keyframes slideInFromRight {
  0% {
    transform: translateX(100%);
    opacity: 0;
  }
  100% {
    transform: translateX(0);
    opacity: 1;
  }
}

@keyframes slideInFromLeft {
  0% {
    transform: translateX(-100%);
    opacity: 0;
  }
  100% {
    transform: translateX(0);
    opacity: 1;
  }
}

/* Global scrollbar styling */
::-webkit-scrollbar {
  width: 8px;
}

::-webkit-scrollbar-track {
  background: rgba(255, 255, 255, 0.1);
  border-radius: 4px;
}

::-webkit-scrollbar-thumb {
  background: linear-gradient(45deg, #FFD700, #FFA500);
  border-radius: 4px;
}

::-webkit-scrollbar-thumb:hover {
  background: linear-gradient(45deg, #FFA500, #FF8C00);
}

/* Selection styling */
::selection {
  background: rgba(255, 215, 0, 0.3);
  color: inherit;
}

/* Smooth scrolling */
html {
  scroll-behavior: smooth;
}

/* Focus outline for accessibility */
*:focus {
  outline: 2px solid #FFD700;
  outline-offset: 2px;
}
`;

// Inject global styles
const styleElement = document.createElement('style');
styleElement.textContent = globalStyles;
document.head.appendChild(styleElement);

export default App;